<template>
    <h1 class="text-2xl font-semibold text-gray-700">
        <slot />
    </h1>
</template>
